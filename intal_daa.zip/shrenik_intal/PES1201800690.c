#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "intal.h"

#define lld long long int
#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b

static char *clear_init_zeros(char *str)
{
	lld n = strlen(str);
	lld count = 0, i;
	//count number of consecutive zeros
	//if non-zero value is encountered,break.
	for (i = 0; i < n; i++)
	{
		if (str[i] == '0')
			count++;
		else
			break;
	}
	//if none of them are zero, exit
	if (count == 0)
		return str;
	//if all of them are zeros
	//string is "0"
	else if (count == n)
	{
		char *str1 = (char*)malloc(sizeof(char) * 2);
		str1[0] = '0';
		str1[1] = '\0';
		return str1;
	}
	//else if in between, allocate string of length n
	//plus 1 for \0 and subtract count of zeros to get string
	//with no leading zeros
	//copy values.
	//return the resultant string
	else
	{

		char*str1 = (char*)malloc(sizeof(char) * (n + 1 - count));
		long long int j = 0;
		while (str[count] != '\0')
			str1[j++] = str[count++];
		str1[j] = '\0';

		return str1;
		free(str1);
	}

}
//char *strrev(char *str)
//strrev() works only in turbo c, not gcc
static char* strrev(char *str, int n)
{
	//keep swapping elements from both ends.
	lld i = 0;
	lld j = n - 1;
	char ch;
	for (i = 0; i < j; i++, j--)
	{
		ch = str[i];
		str[i] = str[j];
		str[j] = ch;
	}
	return str;
}

char* intal_add(const char* intal1, const char* intal2)
{
	/*Algorithm
	*Create string1 for holding intal1
	*Create string2 for holding intal2
	*plus 1s for holding null char
	*Copy strings respectively
	*Calculate lengths len1 and len2
	*Reverse the strings
	*Create string3 of greater string's length + 1(null char) + 1(addition might lead to extra digit)
	*Set max and min values for strings based on length
	*Iterate through min for first digit and calculate carry and sum
	*"Carry" the carry
	*Keep doing it and reverse the string in the end to get res sum
	*/
	char *str1 = (char*)malloc(sizeof(char) * (strlen(intal1) + 1));
	char *str2 = (char*)malloc(sizeof(char) * (strlen(intal2) + 1));
	strcpy(str1, intal1);
	strcpy(str2, intal2);

	lld len1 = strlen(intal1);
	lld len2 = strlen(intal2);
	str1 = strrev(str1, len1);
	str2 = strrev(str2, len2);

	char *str3;
	if (len1 > len2)
		str3 = (char*)malloc(sizeof(char) * (len1 + 2));
	else
		str3 = (char*)malloc(sizeof(char) * (len2 + 2));

	lld min, max, sum, carry = 0, i = 0, j = 0;
	if (len1 < len2)
	{
		max = len2;
		min = len1;
	}
	else
	{
		max = len1;
		min = len2;
	}
	while (i < min)
	{
		if (i == 0)
		{
			sum = str1[i] - '0' + str2[i] - '0';
			carry = sum / 10;
			sum %= 10;
		}
		else
		{
			sum = str1[i] - '0' + str2[i] - '0' + carry;
			carry = sum / 10;
			sum %= 10;
		}
		str3[j++] = sum + '0';
		i++;

	}
	if (max == len1)
	{
		while (i < len1)
		{
			sum = str1[i] - '0' + carry;
			carry = sum / 10;
			sum = sum % 10;
			i = i + 1;
			str3[j++] = sum + '0';
		}
	}
	else if (max == len2)
	{
		while (i < len2)
		{
			sum = str2[i] - '0' + carry;
			carry = sum / 10;
			sum = sum % 10;
			i = i + 1;
			str3[j++] = sum + '0';
		}
	}
	if (carry != 0)
	{
		str3[j++] = carry + '0';
	}

	str3[j] = '\0';
	str3 = strrev(str3, strlen(str3));
	str3 = clear_init_zeros(str3);

	free(str1);
	free(str2);

	return str3;
	free(str3);
}

int intal_compare(const char* intal1, const char* intal2)
{
	/*This one's pretty straightforward.
	 *Calculate lengths len1 and len2 of the two strings
	 *If len1 is greater return 1
	 *If len2 is greater return -1
	 *If they're equal,check digits in each string over their lengths
	 *If it makes it through all of this, return 0
	*/

	int len1 = strlen(intal1);
	int len2 = strlen(intal2);
	if (len1 > len2)
		return 1;
	else if (len1 < len2)
		return -1;
	else if (len1 == len2)
	{
		for (lld i = 0; i < len1; i++)
		{
			if (intal1[i] > intal2[i])
				return 1;
			else if (intal1[i] < intal2[i])
				return -1;
		}
	}
	return 0;
}

char* intal_diff(const char* intal1, const char* intal2)
{
	/*Algorithm
	 *Make intal 1 greater than intal2
	 *To do that, allocate two strings and copy intal1 and intal2 values
	 *intal_compare==-1 => create temporary strings and swap
	 *Reverse the strings
	 *Iterate through and subtract digits
	 *Move carry if negative result
	 *Reverse the result and clear the initial zeros to retrieve correct difference (non negative).
	*/
	char*str1 = (char*)malloc(sizeof(char) * (strlen(intal1) + 1));
	char*str2 = (char*)malloc(sizeof(char) * (strlen(intal2) + 1));

	strcpy(str1, intal1);
	strcpy(str2, intal2);

	int compare = intal_compare(str1, str2);
	if (compare == -1)
	{
		char*temp = (char*)malloc(sizeof(char) * (strlen(str1) + 1));
		char*temp1 = (char*)malloc(sizeof(char) * (strlen(str2) + 1));
		strcpy(temp, str1);
		strcpy(temp1, str2);
		str1 = (char*)realloc(str1, strlen(str2));
		str2 = (char*)realloc(str2, strlen(str1));
		strcpy(str1, temp1);
		strcpy(str2, temp);
		free(temp);
		free(temp1);
	}

	str1 = strrev(str1, strlen(str1));
	str2 = strrev(str2, strlen(str2));

	int l1 = strlen(str1);
	int l2 = strlen(str2);

	int k = 0;
	int carry = 0;
	char *res = (char*)malloc(sizeof(char) * (l1 + 1));
	for (int i = 0; i < l2; i++)
	{
		int sub = ((str1[i] - '0') - (str2[i] - '0') - carry);
		if (sub < 0)
		{
			sub = sub + 10;
			carry = 1;
		}
		else
		{
			carry = 0;
		}
		res[k++] = sub + '0';
	}

	for (int i = l2; i < l1; i++)
	{
		int sub = ((str1[i] - '0') - carry);
		if (sub < 0)
		{
			sub = sub + 10;
			carry = 1;
		}
		else
			carry = 0;
		res[k++] = sub + '0';


	}
	res[k] = '\0';

	res = strrev(res, strlen(res));
	res = clear_init_zeros(res);

	free(str1);
	free(str2);
	return res;
	free(res);
}

char* intal_multiply(const char* intal1, const char* intal2)
{
	/*If both the numbers are 0, return 0
	 *Create result string of size intal1+intal2 + 2(null)
	 *Start from last digit and multiply with the other number
	 *Right to left in firstnum
	 *Shift position to left after every multiplication of a digit in the 2nd num
	 *Use nested loop to go from right to left in 2nd num
	 *Multiply with current digit of first number and add result to previously stored num
	 *Calculate carry for next iteration
	 *Store the results
	 *Generate result string
	 */
	if (intal1[0] == 48 || intal2[0] == 48)
	{
		char *res = (char*)malloc(sizeof(char) * 2);
		res[0] = '0';
		res[1] = '\0';
		return res;
		free(res);
	}

	int a = strlen(intal1);
	int b = strlen(intal2);
	int total = a + b;
	char *result = malloc(sizeof(char) * (total + 2));

	int i_n1 = 0;
	int i_n2 = 0;
	int i;
	for (int i = 0; i < total + 2; i++)
		result[i] = '0';

	for (i = a - 1; i >= 0; i--)
	{
		int carry = 0;
		int n1 = intal1[i] - '0';
		i_n2 = 0;

		for (int j = b - 1; j >= 0; j--)
		{
			int n2 = intal2[j] - '0';

			int s = n1 * n2 + (result[i_n1 + i_n2] - '0') + carry;
			carry = s / 10;
			result[i_n1 + i_n2] = '0' + (s % 10);

			i_n2++;
		}

		if (carry > 0)
			result[i_n1 + i_n2] = '0' + result[i_n1 + i_n2] - '0' + carry;

		i_n1++;
	}

	int k = i_n1 + i_n2;
	k--;

	while (result[k] == '0')
		k--;

	result[k + 1] = '\0';

	strrev(result, strlen(result));
	return result;
	free(result);
}

char* intal_mod(const char* intal1, const char* intal2)
{
	/*Algorithm
	 *Use compare function, if -1, intal1 is smaller => return intal1
	 *Use compare function, if 0, intal1=intal2 => return 0
	 *Calculate lengths and initialize a new curr array
	 *Update 2nd value p till 1st value stop based on 2 conditions:
	 *1)if "current" is less than intal2 and
	 *2)if "current" is greater than or equal to intal 2
	 *Do this until "p" is equal to "stop"
	 *Reallocate and return the current array which holds
	 *the result
	 */

	int cmp = intal_compare(intal1, intal2);
	if (cmp == -1)
	{
		char* result = (char*)malloc((strlen(intal1) + 1) * sizeof(char));
		strcpy(result, intal1);
		return result;
		free(result);

	}
	else if (cmp == 0)
	{
		char* result = (char*)malloc((2) * sizeof(char));
		strcpy(result, "0");
		return result;
		free(result);
	}

	int p = strlen(intal2);
	int stop = strlen(intal1);
	char* current = (char*)malloc((strlen(intal2) + 2) * sizeof(char));
	for (int i = 0; i < p; i++)
		current[i] = intal1[i];
	current[p] = '\0';

	do
	{
		if (intal_compare(current, intal2) == -1 && p < stop)
		{
			int len = strlen(current);
			if (strcmp(current, "0") == 0)
				len = 0;

			current[len] = intal1[p];
			current[len + 1] = '\0';
			++p;
		}

		if (intal_compare(current, intal2) != -1)
		{
			char* result = intal_diff(current, intal2);
			while (intal_compare(result, intal2) > -1)
			{
				char* temp = result;
				result = intal_diff(result, intal2);
				free(temp);
			}

			strcpy(current, result);
			free(result);
		}
	} while (p < stop);

	current = realloc(current, (strlen(current) + 1) * sizeof(char));
	current[strlen(current) + 1] = '\0';
	return current;
	free(current);
}

char * intal_pow(const char *intal1, unsigned int n)
{
	/*Algorithm
	 *If n is 0, return 1
	 *a power n = (a square)^(n/2) if n%2==0
	 *a power n = (a square)^(n/2) * a if n is odd as learnt in unit 3
	 *Recursively compute these values using intal_multiply
	 */
	if (n == 0)
	{
		char *res = malloc(sizeof(char) * 2);
		res[0] = '1';
		res[1] = '\0';

		return res;
		free(res);
	}

	else if (n % 2 == 0)
		return intal_multiply(intal_pow(intal1, n / 2), intal_pow(intal1, n / 2));
	else
		return intal_multiply(intal1, intal_multiply(intal_pow(intal1, n / 2), intal_pow(intal1, n / 2)));
}


char* intal_gcd(const char* intal1, const char* intal2)
{
	/*Straighforward use of Euclid's algorithm
	 *GCD(m,n) = GCD(N,M MOD N)
	 *Repeat until m is 0
	 *Return n
	 */

	char *m = (char*)malloc((strlen(intal1) + 1) * sizeof(char));
	char *n = (char*)malloc((strlen(intal2) + 1) * sizeof(char));
	strcpy(m, intal1);
	strcpy(n, intal2);

	int flag = strcmp(m, "0");
	while (flag != 0)
	{
		char *temp = n;
		n = m;
		m = intal_mod(temp, m);

		free(temp);
		flag = strcmp(m, "0");
	}

	free(m);
	return n;
	free(n);
}

char* intal_fibonacci(unsigned int n)
{
	/*Algorithm
	 *If n is 0, create array containing 0 and return value
	 *If n is 1, return 1
	 *For n>1, inside a for loop, keep adding 2 previous values
	 *to compute result
	 */

	char *first = (char*)malloc(2 * sizeof(char));
	first[0] = '0';
	first[1] = '\0';
	if (n == 0)
		return first;

	char *second = (char*)malloc(2 * sizeof(char));
	second[0] = '1';
	second[1] = '\0';

	if (n == 1)
		return second;

	for (int i = 1; i < n; i++)
	{
		char* third = intal_add(first, second);
		free(first);
		first = second;
		second = third;
	}

	free(first);
	return second;
}

char* intal_factorial(unsigned int n)
{
	/*Algorithm
	 *If n is 0 return 1
	 *Iterate through using a for loop to multiply
	 *string with consecutive values till n (incl.)
	 *return string
	 */
	char *str = intal_add("0", "1");
	char *mul = intal_add("0", "1");
	char *add = intal_add("0", "1");
	if (n == 0)
		return "1";
	else
	{

		for (long long int i = 2; i <= n; i++)
		{
			mul = intal_add(mul, add);
			str = intal_multiply(str, mul);
		}

	}
	free(mul);
	return str;

}

int intal_max(char **arr, int n)
{
	/*Algorithm
	 *Let position of max element be 0
	 *Compare the rest of the elements with element at 0th pos
	 *If found at ith location, make the position of the max element to be i
	 *Return max_position
	 */
	int max_pos = 0;
	for (int i = 1; i < n; i++)
	{
		if (intal_compare(arr[i], arr[max_pos]) == 1)
			max_pos = i;
	}
	return max_pos;
}

int intal_min(char **arr, int n)
{
	/*Algorithm
	 *Let position of min element be 0
	 *Compare the rest of the elements with element at 0th pos
	 *If found at ith location, make the position of the min element to be i
	 *Return min_position
	 */
	int min_pos = 0;

	for (int i = 1; i < n; i++)
	{
		if (intal_compare(arr[min_pos], arr[i]) == 1)
			min_pos = i;
	}
	return min_pos;
}
char* intal_bincoeff(unsigned int n, unsigned int k)
{
	/*Method 1 is the direct formula which is likely to
	 *overflow even for small values of n and k
	 *Method 2 requires replacing the fraction in method 1
	 *with a product of k factors.
	 *Method 3 using Pascal's relation: we can construct a table
	 *of binomial coefficients. This is done without initializing O(nk) table
	 *Pascal's identity C(n,k) = C(n-1,k) + C(n-1,k-1)
	 *The intermediate results don't exceed ans
	 *TC: O(n^2) SC: O(K)
	 *Array implementation
	 *
	 *We can also precompute factorials in
	 *only 2 divisions to get ans in O(1)
	*/
	char** table = (char**) malloc((k + 1) * sizeof(char*));
	for (int i = 0; i <= k; i++)
	{
		table[i] = (char*) malloc(1001 * sizeof(char));
		strcpy(table[i], "0");
	}
	strcpy(table[0], "1");

	for (int i = 1; i <= n; i++)
	{
		for (int j = min(i, k); j > 0; j--)
			table[j] = intal_add(table[j], table[j - 1]);
	}
	return table[k];
}


int intal_search(char **arr, int n, const char* key)
{
	/*
	 *Linear Search to find first occurence
	 *O(n) time
	 *Compare each item with key, return position if found
	 *Else return -1 if not found
	 */
	char *str1 = (char*)malloc(sizeof(char) * 1001);
	for (int i = 0; i < n; i++)
	{
		strcpy(str1, arr[i]);
		if (intal_compare(str1, key) == 0)
			return i;
	}
	free(str1);
	return -1;
}



static void merge(char** arr, int l, int m, int r)
{
	/*Using merge sort to sort an array of n intals
	 *Time Complexity of nlogn in all cases
	 *Merge sort divides input array into 2 halves
	 *It calls itself for two halves and merges them.
	 */

	int i, j, k;
	int n1 = m - l + 1;
	int n2 = r - m;

	char* L[n1], *R[n2];

	for (i = 0; i < n1; i++)
		L[i] = arr[l + i];
	for (j = 0; j < n2; j++)
		R[j] = arr[m + 1 + j];

	i = 0;
	j = 0;
	k = l;
	while (i < n1 && j < n2)
	{
		if (intal_compare(L[i], R[j]) <= 0)
		{
			arr[k] = L[i];
			i++;
		}
		else
		{
			arr[k] = R[j];
			j++;
		}
		k++;
	}
	while (i < n1)
	{
		arr[k] = L[i];
		i++;
		k++;
	}
	while (j < n2)
	{
		arr[k] = R[j];
		j++;
		k++;
	}
}
static void merge_sort(char **arr, int l, int r)
{
	if (l < r)
	{
		int m = l + (r - l) / 2;

		merge_sort(arr, l, m);
		merge_sort(arr, m + 1, r);
		merge(arr, l, m, r);
	}
}

void intal_sort(char **arr, int n)
{
	merge_sort(arr, 0, n - 1);
}



int intal_binsearch(char **arr, int n, const char* key)
{
	/*To find first occurence,
	 *follow the binary search algorithm but
	 *do not stop and return if key is at mid
	 *start looking in the left.
	 *Use the "result" variable to keep track of this
	 *Modify search space by changing r to mid-1
	 *The above algorithm takes care of duplicates
	 *and cases like "1 1 2 2 3 7 5"
	 */
	int l = 0;
	int r = n - 1;
	int result = -1;
	while (l <= r)
	{
		int mid = l + (r - l) / 2;

		if (intal_compare(arr[mid], key) == 0)
		{
			result = mid;
			r = mid - 1;
		}
		else if (intal_compare(arr[mid], key) == 1)
			r = mid - 1;
		else
			l = mid + 1;
	}
	return result;
}


char* coin_row_problem(char **arr, int n)
{
	/*Classic DP Problem
	 *O(n) time and O(n) for table + O(1) extra space
	 *Partiion allowed coin selections into 2 groups:
	 *Update each index to max(sum of present index value +
	 *sum of present present index value -2 ) i.e
	 *F(n) = max{Cn + F(n-2) + F(n-1)} for all n>1
	 *Base cases will be F(0)=0 obviously and F(1) = c1
	 */

	char** dp = (char**)malloc((n + 1) * sizeof(char*));

	dp[0] = (char*)malloc(2 * sizeof(char));
	dp[0][0] = '0';
	dp[0][1] = '\0';

	for (int i = 0; i < n; i++)
	{
		dp[i + 1] = (char*)malloc(sizeof(char) * (strlen(arr[i]) + 1));
		strcpy(dp[i + 1], arr[i]);
	}

	for (int i = 2; i < n + 1; i++)
	{
		char* val = intal_add(arr[i - 1], dp[i - 2]);
		if (intal_compare(val, dp[i - 1]) > 0)
		{
			char* temp = dp[i];
			dp[i] = val;
			free(temp);
		}
		else
		{
			free(dp[i]);
			dp[i] = (char*) malloc(sizeof(char) * (strlen(dp[i - 1]) + 1));
			strcpy(dp[i], dp[i - 1]);
			free(val);
		}
	}

	char* result = (char*)malloc(sizeof(char) * (strlen(dp[n]) + 1));
	strcpy(result, dp[n]);

	for (int i = 0; i < n + 1; i++)
	{
		free(dp[i]);
	}
	free(dp);

	return result;

}